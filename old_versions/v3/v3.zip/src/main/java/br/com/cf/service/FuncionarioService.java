package br.com.cf.service;

import br.com.cf.domain.pojos.FuncionarioPOJO;

public interface FuncionarioService extends CustomService<FuncionarioPOJO> {
}