package br.com.cf.service;

import br.com.cf.domain.pojos.ClientePOJO;

public interface ClienteService extends CustomService<ClientePOJO> {
}