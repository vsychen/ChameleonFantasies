package dados.repositorios.iterator;

public interface IIterator {
	boolean hasNext();

	Object next();
}